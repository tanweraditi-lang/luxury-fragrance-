import { User, ShoppingBag, ArrowRight, MessageCircle, RefreshCcw, ShieldCheck, Truck, Plane } from 'lucide-react';

const mainPerfumeImage = "/secret.png";
const perfumeSeduction = "/secret.png";
const perfumePassion = "/secret.png";
const perfumeSantorini = "/secret.png";
const perfumeIntense = "/secret.png";
const perfumeTropez = "/secret.png";

export default function App() {
  return (
    <div className="font-sans text-gray-900 bg-white min-h-screen overflow-x-hidden">
      {/* Navbar */}
      <nav className="sticky top-0 w-full z-50 flex items-center justify-between px-6 md:px-16 py-6 bg-white border-b border-gray-100 shadow-sm">
        <div className="text-2xl font-serif tracking-widest font-bold uppercase">Secrets</div>
        <div className="hidden md:flex gap-12 text-sm uppercase tracking-widest font-semibold text-gray-800">
          <a href="#" className="hover:text-teal-600 transition-colors">Collections</a>
          <a href="#" className="hover:text-teal-600 transition-colors">Our story</a>
          <a href="#" className="hover:text-teal-600 transition-colors">Journals</a>
          <a href="#" className="hover:text-teal-600 transition-colors">Contact</a>
        </div>
        <div className="flex gap-4">
          <div className="w-10 h-10 rounded-full bg-teal-50 flex items-center justify-center text-teal-800 cursor-pointer hover:bg-teal-100 transition-colors">
            <User size={18} strokeWidth={2.5} />
          </div>
          <div className="w-10 h-10 rounded-full bg-teal-50 flex items-center justify-center text-teal-800 cursor-pointer hover:bg-teal-100 transition-colors relative">
            <ShoppingBag size={18} strokeWidth={2.5} />
            <span className="absolute -top-1 -right-1 bg-black text-white text-[10px] w-4 h-4 flex items-center justify-center rounded-full font-bold">2</span>
          </div>
        </div>
      </nav>

      {/* New Hero Section */}
      <div 
        className="relative w-full h-[calc(100vh-88px)] flex items-center overflow-hidden bg-[#FDFBF7]"
        style={{
          backgroundImage: `url('/hero.png')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center right',
          backgroundRepeat: 'no-repeat'
        }}
      >
        {/* Gradient Overlay for text readability (only strong on the left where text is) */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#FDFBF7] via-[#FDFBF7]/80 to-transparent w-full md:w-2/3"></div>

        <div className="w-full max-w-[1400px] mx-auto px-6 md:px-16 flex flex-col items-start relative z-10 pt-20 md:pt-0">
          <div className="w-full md:w-2/3 lg:w-1/2 flex flex-col items-start mt-10 md:mt-0">
            <h1 className="text-5xl md:text-7xl lg:text-[5.5rem] leading-[1.1] font-serif font-medium italic text-gray-900 uppercase tracking-wide mb-6">
              Wear luxury <br/> Keep mystery
            </h1>
            <p className="max-w-md text-lg md:text-xl font-medium leading-relaxed text-gray-800 mb-10">
              Experience timeless sophistication, designed for those who leave a little mystery behind.
            </p>
            <button className="group relative overflow-hidden bg-gray-900 text-white rounded-full px-10 py-4 flex items-center gap-4 transition-all duration-300 hover:shadow-[0_8px_30px_rgb(0,0,0,0.12)] hover:scale-[1.02] active:scale-[0.98] font-semibold uppercase tracking-[0.2em] text-xs">
              <span className="relative z-10 flex items-center gap-3">
                Shop Now 
                <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform duration-300"/>
              </span>
              <div className="absolute inset-0 h-full w-full bg-gradient-to-r from-teal-900 via-gray-800 to-gray-900 opacity-0 group-hover:opacity-100 transition-opacity duration-500 z-0"></div>
            </button>
          </div>
        </div>
      </div>

      {/* Section 2 - Info paragraphs */}
      <div className="w-full bg-[#FDFBF7] py-24 px-6 md:px-16 z-30 relative">
        <div className="flex flex-col md:flex-row items-center max-w-7xl mx-auto gap-12">
          
          <div className="w-full md:w-1/2 text-center md:text-left z-30 bg-white/40 md:bg-transparent backdrop-blur-md md:backdrop-blur-none p-6 md:p-0 rounded-3xl">
            <p className="text-sm md:text-base leading-relaxed text-gray-800 font-medium">
              <strong className="text-xl font-serif text-black block mb-3">Secret Santorini</strong>
              is a symphony of scents that captures the serene beauty and vibrant culture of the Greek island. Imagine standing by the Aegean Sea, with the gentle breeze carrying the aroma of blooming jasmine and sun-kissed citrus. This perfume captures the essence of a sun-kissed escape, bright and sparkling at the top with notes of bergamot and mandarin, softening into a floral heart of white jasmine and neroli, and settling into a warm base of sandalwood and musk. Perfect for the daydreamers and wanderers, it feels like a secret waiting to be discovered.
            </p>
          </div>
          
          <div className="w-full md:w-1/2 flex flex-col items-center md:items-start text-center md:text-left mt-8 md:mt-0 z-30 bg-white/40 md:bg-transparent backdrop-blur-md md:backdrop-blur-none p-6 md:p-0 rounded-3xl">
            <p className="text-sm md:text-base leading-relaxed text-gray-800 font-medium mb-8">
              At <strong className="font-serif text-lg text-black">Secrets</strong>, we believe that a fragrance is more than just a scent — it’s a reflection of your personality, an unseen accessory that leaves a lasting impression. Our journey began with a simple idea: to create a collection of perfumes that tell a story, evoke emotions, and transport you to a different place and time. Each of our perfumes is carefully crafted with rare, high-quality ingredients and a dedication to timeless elegance and mystery. With Secrets, you don't just wear a fragrance; you embrace a lifestyle.
            </p>
            <button className="bg-transparent text-gray-900 rounded-none px-0 py-2 flex items-center gap-3 border-y border-gray-400 hover:text-teal-800 transition-colors font-serif italic tracking-widest text-lg uppercase">
              Shop Now
            </button>
          </div>

        </div>
      </div>

      {/* Section 3 - Features */}
      <div className="py-24 bg-white relative z-40">
        <div className="max-w-7xl mx-auto flex flex-wrap justify-center md:justify-between gap-12 px-6 md:px-16">
          <Feature icon={MessageCircle} text="Smooth communication" />
          <Feature icon={RefreshCcw} text="Easy Returns" />
          <Feature icon={ShieldCheck} text="Quality Assurance" />
          <Feature icon={Truck} text="Quick Delivery" />
          <Feature icon={Plane} text="Swift shipment policy" />
        </div>
      </div>

      {/* Section 4 - Product Showcase */}
      <div className="min-h-screen bg-gray-50 py-32 z-40 relative rounded-t-[3rem] shadow-[0_-10px_40px_rgba(0,0,0,0.03)]">
        <h2 className="text-4xl md:text-6xl font-serif text-center font-bold mb-24 text-gray-900">Keeping your Secrets here</h2>
        
        <div className="max-w-[90rem] mx-auto flex flex-wrap justify-center gap-x-8 gap-y-16 px-6 md:px-16">
           <ProductCard image={perfumeSeduction} price="$79.99" name="Seduction" />
           <ProductCard image={perfumePassion} price="$79.99" name="Passion" />
           <ProductCard image={perfumeSantorini} price="$59.99" name="Santorini" />
           <ProductCard image={perfumeIntense} price="$79.99" name="Intense" />
           <ProductCard image={perfumeTropez} price="$79.99" name="Tropez" />
        </div>
      </div>
    </div>
  );
}

function Feature({ icon: Icon, text }: { icon: any, text: string }) {
  return (
    <div className="flex flex-col items-center gap-5 text-center max-w-[140px] group">
      <div className="w-20 h-20 rounded-full border border-gray-200 bg-white flex items-center justify-center text-gray-800 group-hover:border-teal-400 group-hover:bg-teal-50 group-hover:text-teal-700 transition-all duration-300 shadow-sm group-hover:shadow-md cursor-pointer group-hover:-translate-y-1">
        <Icon size={32} strokeWidth={1.5} />
      </div>
      <p className="text-sm font-semibold text-gray-800 leading-snug uppercase tracking-wide">{text}</p>
    </div>
  );
}

function ProductCard({ image, price, name }: { image: string, price: string, name: string }) {
  return (
    <div className="flex flex-col items-center gap-6 group cursor-pointer w-56">
      <div className="w-full h-72 flex items-center justify-center p-4 relative">
        {/* Subtle background blob on hover */}
        <div className="absolute inset-0 bg-teal-100 rounded-full blur-2xl opacity-0 group-hover:opacity-40 transition-opacity duration-500"></div>
        <img 
          src={image} 
          alt={name} 
          className="w-full h-full object-contain mix-blend-multiply drop-shadow-xl group-hover:scale-110 transition-transform duration-500 relative z-10" 
          referrerPolicy="no-referrer"
        />
      </div>
      <div className="text-center mt-2">
        <p className="text-teal-700 font-bold text-xl tracking-wide">{price}</p>
        <p className="text-gray-900 font-serif text-3xl font-bold mt-1 group-hover:text-teal-800 transition-colors">{name}</p>
      </div>
    </div>
  );
}
